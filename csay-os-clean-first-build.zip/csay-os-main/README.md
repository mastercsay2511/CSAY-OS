# CSAY OS   [![bluebuild build badge](https://github.com/mastercsay2511/csay-os/actions/workflows/build.yml/badge.svg)](https://github.com/mastercsay2511/csay-os/actions/workflows/build.yml)

**CSAY OS** is a custom BlueBuild-based atomic Fedora image designed to provide a private, secure, reproducible, and self-healing desktop operating system foundation.

This repository contains the build configuration, modules, files, signing key, and GitHub Actions workflow required to build and publish the CSAY OS container image.

## Image

The current image target is:

```text
ghcr.io/mastercsay2511/csay-os:latest
```

After a successful GitHub Actions build, this image should appear under this repository’s GitHub Packages.

## Purpose

CSAY OS is built to provide a controlled operating system base that can be rebuilt, verified, updated, and extended from source configuration.

The project is intended to support:

* Atomic Fedora-based system deployment
* BlueBuild image customization
* Reproducible operating system builds
* Signed container image verification
* Controlled desktop/system foundation
* Future expansion through CSAY modules
* Cleaner separation between base OS, custom files, and modular configuration

## Repository Structure

```text
csay-os/
├── .github/
│   └── workflows/
│       └── build.yml
├── files/
├── modules/
├── recipes/
│   └── recipe.yml
├── .gitignore
├── LICENSE
├── README.md
└── cosign.pub
```

### Important paths

| Path                          | Purpose                                 |
| ----------------------------- | --------------------------------------- |
| `recipes/recipe.yml`          | Main BlueBuild image recipe             |
| `modules/`                    | Custom BlueBuild modules                |
| `files/`                      | Files copied into the final image       |
| `.github/workflows/build.yml` | GitHub Actions build workflow           |
| `cosign.pub`                  | Public key used to verify signed images |
| `LICENSE`                     | Repository license                      |

## Build Source

The main image configuration is defined in:

```text
recipes/recipe.yml
```

The recipe controls the image name, base image, description, modules, and build behavior.

The current image name should remain:

```yaml
name: csay-os
```

This name is used to publish the image as:

```text
ghcr.io/mastercsay2511/csay-os:latest
```

## Base Image

CSAY OS uses a BlueBuild-compatible Fedora Atomic base image.

Before building or installing, confirm the base image in:

```text
recipes/recipe.yml
```

If the system uses NVIDIA hardware, an NVIDIA-compatible base image may be required.

If the system uses AMD or Intel graphics, use the standard compatible base image recommended by BlueBuild/Bazzite for that hardware.

Do not install the image on important hardware until the base image matches the target machine.

## Building the Image

The image is built through GitHub Actions.

To run a manual build:

```text
GitHub → Actions → bluebuild → Run workflow → Branch: main → Run workflow
```

After the workflow completes successfully, check:

```text
GitHub repository → Packages
```

The expected package should be:

```text
ghcr.io/mastercsay2511/csay-os
```

## Required Secret

The build workflow may require a signing secret.

Check that this repository has the following GitHub Actions secret:

```text
SIGNING_SECRET
```

Location:

```text
GitHub repository → Settings → Secrets and variables → Actions → Repository secrets
```

GitHub will show the secret name after it is created, but it will not show the saved secret value.

## Installation

> [!WARNING]
> CSAY OS is an experimental custom operating system image. Test it carefully on non-critical hardware before using it as a daily system.

To rebase an existing Fedora Atomic installation to the latest CSAY OS build, use the following process.

### 1. Rebase to the unsigned image

This first step allows the system to receive the signing keys and policies included in the image:

```bash
rpm-ostree rebase ostree-unverified-registry:ghcr.io/mastercsay2511/csay-os:latest
```

### 2. Reboot

```bash
systemctl reboot
```

### 3. Rebase to the signed image

After the first reboot, switch to the signed image:

```bash
rpm-ostree rebase ostree-image-signed:docker://ghcr.io/mastercsay2511/csay-os:latest
```

### 4. Reboot again

```bash
systemctl reboot
```

After the second reboot, the system should be running CSAY OS.

## Updating

The `latest` tag points to the latest successful build.

CSAY OS still follows the Fedora version configured inside:

```text
recipes/recipe.yml
```

This means the system will not automatically move to the next major Fedora version unless the recipe is changed.

To update an installed system after a new successful build:

```bash
rpm-ostree upgrade
```

Then reboot:

```bash
systemctl reboot
```

## Rollback

Fedora Atomic systems support rollback if the new deployment does not work correctly.

To roll back to the previous deployment:

```bash
rpm-ostree rollback
```

Then reboot:

```bash
systemctl reboot
```

## Verification

CSAY OS images are signed with Sigstore/cosign.

Download the `cosign.pub` file from this repository, then verify the image with:

```bash
cosign verify --key cosign.pub ghcr.io/mastercsay2511/csay-os:latest
```

Verification confirms that the image was signed with the matching signing key.

## ISO Generation

If building from a Fedora Atomic system, an offline ISO can be generated using the BlueBuild ISO process:

```text
https://blue-build.org/how-to/generate-iso/#_top
```

Large ISO files are usually not suitable for free GitHub hosting because of file size limits. Public ISO distribution should use separate release storage, artifact storage, or another hosting provider.

## Development Workflow

Recommended development process:

```text
1. Edit recipes/recipe.yml, modules/, or files/
2. Commit changes to main
3. Run the bluebuild GitHub Actions workflow
4. Confirm the workflow succeeds
5. Confirm the GHCR package is published
6. Test on non-critical hardware
7. Only then consider using it on a primary system
```

## Safety Notes

Before installing CSAY OS:

* Confirm the image builds successfully
* Confirm the package exists in GitHub Packages
* Confirm the base image matches the target hardware
* Confirm signing verification works
* Test on non-critical hardware first
* Keep rollback access available
* Do not use the image as a primary system until it has been validated

## License

This repository uses the license defined in the `LICENSE` file.

## Boot Splash Theme

This image includes a custom **CSAY OS Plymouth boot splash**.

Files for the boot theme live in:

```text
files/system/usr/share/plymouth/themes/csay-os/
```

The image build copies the theme into the final system, sets it as the default Plymouth theme, and regenerates initramfs so the branding appears during boot.

