#!/usr/bin/env bash
set -euo pipefail

THEME_DIR="/usr/share/plymouth/themes/csay-os"
THEME_FILE="$THEME_DIR/csay-os.plymouth"
DEFAULT_THEME_LINK="/usr/share/plymouth/themes/default.plymouth"

if [[ -f "$THEME_FILE" ]]; then
  ln -sf "$THEME_FILE" "$DEFAULT_THEME_LINK"
fi

mkdir -p /etc/plymouth
cat > /etc/plymouth/plymouthd.conf <<'CONF'
[Daemon]
Theme=csay-os
ShowDelay=0
DeviceTimeout=8
CONF
