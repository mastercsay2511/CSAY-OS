# CSAY OS First Build Note

This package is prepared for the first clean GitHub build.

Signing has been temporarily disabled to avoid the current cosign key failure.

Removed for first build:
- `- type: signing` from `recipes/recipe.yml`
- `cosign_private_key: ...` from `.github/workflows/build.yml`

After the image builds successfully, signing can be added back later using:
- `cosign.pub` in the repository root
- `SIGNING_SECRET` as a GitHub Actions Secret, not a variable
